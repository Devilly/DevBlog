Today we wanted to barbecue and concluded our table would not suffice. Therefore, with a little help from my son Mick, I put together a small table from scrap wood.

![Barbecue table](./barbecue-table.jpg)

![Barbecue table from the side](./barbecue-table-side.jpg)

A few notes on how it was made:
* The table legs are made from parts of an old pergola.
* The top was made from a long hardwood plank.
* The apron was made from a piece of hardwood previously used to decorate the front of the house.
* The legs are kept in place by one screw and one nail per exterior side of each leg, with both going from the outside, though the apron into the leg.
* The hardwood top planks are attached to the apron with nails, with the nails being placed in different relative positions to increase the overall stability of the structure.