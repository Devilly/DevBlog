export default class Component {}

