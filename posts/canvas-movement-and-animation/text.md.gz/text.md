```javascript

(await import(`../posts/${postIdentifier}/js/main.js`)).default({
    canvas,
    postIdentifier
})

```
