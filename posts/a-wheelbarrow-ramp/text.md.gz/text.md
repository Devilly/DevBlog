My son, Mick, has a sandbox and a wheelbarrow. To enable him to throw sand in the wheelbarrow back into the sandbox I made a small ramp.

![Ramp](./ramp.jpg)
