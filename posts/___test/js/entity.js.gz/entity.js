export default class Entity {
    #xPosition
    #yPosition

    constructor() {

    }

    draw() {

    }
}