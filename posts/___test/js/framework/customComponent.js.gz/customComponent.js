const { default: Component } = await import('./component.js')

export default class CustomComponent extends Component {}