```javascript
// Let's try executing JS in a blog post.

console.log('Awesome!');
```