After making our previous planter we still had MoestuinMaatjes to spare. So I created another planter, just a bit smaller and without the partitions.

![Planter](./planter.jpg)