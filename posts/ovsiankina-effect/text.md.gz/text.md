When I start a task and am not able to complete it oftentimes I feel the need to continue work on it. For example, when I run out of time I try to find the first possible opportunity to work on it again.

It turns out this phenomenon has a formal name. It is the [Ovsiankina effect](https://en.wikipedia.org/wiki/Ovsiankina_effect).